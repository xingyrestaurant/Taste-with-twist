# Taste-with-twist
Xingy – Where Flavor Meets Passion! Serving mouth-watering Pizzas, juicy Burgers, crispy Broast &amp; delicious Momos – all made fresh, every day
